//Header de funcoesBuscaBin.c

void selectFromWhere(FILE* arqEntrada, regCabecalho aux);
void atualizaStatusEscrita (FILE* arquivo);
void remocaoLogica(FILE* arqEntrada, regCabecalho* cabecalho);
void insertInto(FILE* arquivo, regCabecalho* cabecalho);
