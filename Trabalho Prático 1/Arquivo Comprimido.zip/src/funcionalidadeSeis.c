#include <stdio.h>
#include "headerFuncoes.h"


// void Compactacao(FILE* arqEntrada, FILE* arqSaida, regCabecalho* cabecalho){
    
// }

void funcSeis(char *nomeArqEntrada){
    FILE* arqEntrada;
    arqEntrada = fopen(nomeArqEntrada, "rb");
    testaErroArquivo(arqEntrada);
    
    FILE* arqSaida;
    arqSaida = fopen("temporario.bin", "wb");
    testaErroArquivo(arqSaida);
    regCabecalho aux = inicializaCabecalho();
    atualizaRegCabecalho(arqSaida, aux);

    aux = recuperaCabecalho(arqEntrada);
    verificaStatusLeitura(aux.status);

    //Compactacao(arqEntrada, arqSaida, &aux);
    atualizaRegCabecalho(arqEntrada, aux); 
    
    fclose(arqEntrada);
    binarioNaTela(nomeArqEntrada);
}