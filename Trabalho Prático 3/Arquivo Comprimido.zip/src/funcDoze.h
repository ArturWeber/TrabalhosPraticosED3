
void calculaCiclos(Grafo* gr);
