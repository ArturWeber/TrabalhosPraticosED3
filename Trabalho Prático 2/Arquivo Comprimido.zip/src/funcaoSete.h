
void createIndex(FILE* arqEntrada, FILE* arqSaida, regCabecalho cabecalho, regCabecalhoIndice* cabecalhoIndice);
regCabecalhoIndice inicializaCabecalhoIndice(void);
void atualizaRegCabecalhoIndice (FILE* arquivo, regCabecalhoIndice cabecalho);