
void dijkstraAlgoritmo(Grafo* gr, int idInicial);
void zeraDistancias(Grafo* gr);
int retornaDistanciaVertice(Grafo* gr, int idVertice);
void fluxoMaximo(Grafo *gr);
void menorCaminhoGrafo(Grafo* gr);