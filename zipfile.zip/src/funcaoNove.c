// #include <stdio.h>

// #include "funcoesGeraisT1.h"
// #include "funcoesGeraisT2.h"
// #include "funcaoNove.h"

// void insertIntoIndice(FILE* arqEntrada, FILE* arqIndice, regCabecalho* aux, regCabecalhoIndice* auxIndice) {

// }